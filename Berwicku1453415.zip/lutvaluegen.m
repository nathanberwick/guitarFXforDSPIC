% generate waves for LUT values
%% vriable declaration
clear all;
x = 1;
y = 100;

%t = linspace(0,1,y);
t = 0:1/y:1;

LUTsine   = zeros(x, y);
LUTsaw    = zeros(x, y);
LUTnoise  = zeros(x, y);
LUTsquare = zeros(x, y);

%% buffer generation

LUTnoise  = randn(x, y+1);
LUTnoise  = LUTnoise / max(abs(LUTnoise)); %range between +/- 1

LUTsine   = sin(2*pi*t);
LUTsaw    = sawtooth(2*pi*t);

sq = linspace(0, 2*pi, y+1);
LUTsquare = square(sq);

LUTsquarezeros= LUTsquare;
for i=1:length(LUTsquarezeros)
    if(LUTsquarezeros(i)==-1)
        LUTsquarezeros(i)=0;
    end
end
%% 16 bit unsigned conversion

%must change these all to bytes
LUTsine = LUTsine + 1;
LUTsine = LUTsine * 32768;
LUTsine = LUTsine - 32768;
LUTsine = int16(LUTsine);

LUTsaw = LUTsaw + 1;
LUTsaw = LUTsaw * 32768;
LUTsaw = LUTsaw - 32768;
LUTsaw = int16(LUTsaw);

LUTnoise = LUTnoise + 1;
LUTnoise = LUTnoise * 32768;
LUTnoise = LUTnoise - 32768;
LUTnoise = int16(LUTnoise);

LUTsquare = LUTsquare + 1;
LUTsquare = LUTsquare * 32768;
LUTsquare = LUTsquare - 32768;
LUTsquare = int16(LUTsquare);

LUTsquarezeros = LUTsquarezeros + 1;
LUTsquarezeros = LUTsquarezeros * 32768;
LUTsquarezeros = LUTsquarezeros - 32768;
LUTsquarezeros = int16(LUTsquarezeros);

%% test for overflow
%for i=2:length(LUTsine)
%    if(LUTsine(i)==LUTsine(i-1))
%        a = 09999999999;
%    end
%end

%% writeout
if(1)
csvwrite('LUTnoise.txt',       LUTnoise);
csvwrite('LUTsine.txt',        LUTsine);
csvwrite('LUTsaw.txt',         LUTsaw);
csvwrite('LUTsquare.txt',      LUTsquare);
csvwrite('LUTsquarezeros.txt', LUTsquarezeros);
end